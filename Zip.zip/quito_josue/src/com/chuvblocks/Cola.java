package com.chuvblocks;

import java.util.LinkedList;
import java.util.Queue;

public class Cola {
    Queue<DispositivoJosueQuito> cola;

    public Cola() {
        cola = new LinkedList<>();
    }

    public void predefinirValores() throws Exception {
        try {
            encolar(new DispositivoJosueQuito());
            encolar(new DispositivoJosueQuito("C107", "CISCO", 2022, 15, "ACCESSPOINT"));
            encolar(new DispositivoJosueQuito("A012", "CISCO", 2003, 21, "ROUTER"));
            encolar(new DispositivoJosueQuito("B101", "CISCO", 2021, 3, "SWITCH"));
            encolar(new DispositivoJosueQuito("C103", "CISCO", 2022, 65, "ACCESSPOINT"));
            encolar(new DispositivoJosueQuito("A056", "CISCO", 2015, 12, "ROUTER"));
        } catch (Exception e) {
            throw new Exception("Algun valor predefinido ya esta en la cola!");
        }
    }

    public void encolar(DispositivoJosueQuito dispositivo) throws Exception {
        if (cola.stream().anyMatch(dispositivoJosueQuito -> dispositivoJosueQuito.getCodigo().compareTo(dispositivo.getCodigo()) == 0)) {
            throw new Exception("El dispositivo ya esta en cola");
        }
        cola.add(dispositivo);
    }

    public void desencolar(String codigo, int cantidad) throws Exception {
        DispositivoJosueQuito dispositivo = cola.stream().filter(dispositivoJosueQuito -> dispositivoJosueQuito.getCodigo().compareTo(codigo) == 0).findFirst().orElse(null);
        if (dispositivo == null) {
            throw new Exception("El dispositivo no esta en cola");
        }
        if (cantidad < 0) {
            throw new Exception("La cantidad no puede ser negativa");
        }
        if (cantidad > dispositivo.getCantidad()) {
            throw new Exception("No hay suficiente dispositivos para: " + dispositivo.getCodigo());
        }
        dispositivo.setCantidad(dispositivo.getCantidad() - cantidad);
        if (dispositivo.getCantidad() <= 0) {
            cola.remove(dispositivo);
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        cola.forEach(dispositivo -> sb.append(dispositivo.toString()).append("\n"));
        return sb.toString();
    }
}
