package com.chuvblocks;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana {
    private JPanel mainContent;
    private JTextArea txtDispositivos;
    private JTextField txtCodigo;
    private JTextField txtMarca;
    private JTextField txtAnio;
    private JComboBox cboTipo;
    private JSpinner spCantidad;
    private JButton btnAgregar;
    private JTabbedPane tabbedPane1;
    private JPanel JPIngreso;
    private JTextField txtCodigoD;
    private JSpinner spCantidadD;
    private JButton despacharButton;
    private final Cola oCola = new Cola();
    private static final JFrame frame = new JFrame("Examen");

    public Ventana() {
        try {
            oCola.predefinirValores();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
            System.exit(0);
        }
        txtDispositivos.setText(oCola.toString());
        btnAgregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DispositivoJosueQuito dispositivoAEncolar = new DispositivoJosueQuito(
                        txtCodigo.getText(),
                        txtMarca.getText(),
                        Integer.parseInt(txtAnio.getText()),
                        Integer.parseInt(spCantidad.getValue().toString()),
                        (String) cboTipo.getSelectedItem()
                );
                try {
                    oCola.encolar(dispositivoAEncolar);
                    txtDispositivos.setText(oCola.toString());
                    frame.pack();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }
            }
        });
        despacharButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    oCola.desencolar(txtCodigoD.getText(),Integer.parseInt(spCantidadD.getValue().toString()));
                    txtDispositivos.setText(oCola.toString());
                    frame.pack();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }
            }
        });
    }

    public static void main(String[] args) {
        frame.setContentPane(new Ventana().mainContent);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
